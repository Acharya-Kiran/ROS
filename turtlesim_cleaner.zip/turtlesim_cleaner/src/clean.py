#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import math

current_pose = Pose()
flag = True

def move(speed, distance, isForward):
	#global vel_msg, current_pose
	vel_msg = Twist()

	if(isForward):
		vel_msg.linear.x = abs(speed)
	else:
		vel_msg.linear.x = -abs(speed)
	vel_msg.linear.y = 0
	vel_msg.linear.z = 0
	
	vel_msg.angular.x = 0
	vel_msg.angular.y = 0
	vel_msg.angular.z = 0

	t0 = rospy.Time.now().to_sec()
	distance_moved = 0
	loop_rate = rospy.Rate(10) #10 message per second
	velocity_publisher = rospy.Publisher("/turtle1/cmd_vel", Twist, queue_size = 10)
	
	while True:
		rospy.loginfo("turtle forwards")
		velocity_publisher.publish(vel_msg)		
		t1 = rospy.Time.now().to_sec()
		distance_moved = speed * (t1-t0)
		loop_rate.sleep()
		if (distance_moved > distance):
			rospy.loginfo("distance reached")
			break
	vel_msg.linear.x = 0
	velocity_publisher.publish(vel_msg)

def rotate(angular_speed, relative_angle, clockwise): #angle is passed in radians
	vel_msg = Twist()

	vel_msg.linear.x = 0
	vel_msg.linear.y = 0
	vel_msg.linear.z = 0
	
	vel_msg.angular.x = 0
	vel_msg.angular.y = 0
	
	if(clockwise):
		vel_msg.angular.z = -abs(angular_speed)
	else:
		vel_msg.angular.z = abs(angular_speed)

	current_angle = 0
	t0 = rospy.Time.now().to_sec()
	loop_rate = rospy.Rate(10)
	velocity_publisher = rospy.Publisher("/turtle1/cmd_vel", Twist, queue_size = 10)

	while True:
		rospy.loginfo("turtle rotates")
		velocity_publisher.publish(vel_msg)
		t1 = rospy.Time.now().to_sec()
		current_angle = angular_speed * (t1-t0)
		loop_rate.sleep()
		
		if(current_angle > relative_angle):
			rospy.loginfo("angle moved")
			break

	vel_msg.angular.z = 0
	velocity_publisher.publish(vel_msg)
	 
def degrees2radians(angle_in_degrees):
	return math.radians(angle_in_degrees)

def setDesiredOrientation(desired_angle_radians):
	global current_pose
	relative_angle_radians = desired_angle_radians - current_pose.theta;
	if relative_angle_radians<0 :
		clockwise = True 
	else:
		clockwise = False
	rotate(relative_angle_radians,relative_angle_radians,clockwise)
	

def poseCallback(pose_message):
	global current_pose
	current_pose.x = pose_message.x
	current_pose.y = pose_message.y
	current_pose.theta = pose_message.theta

def moveGoal(goal_pose, distance_tolerance):
	global current_pose
	vel_msg = Twist()
	loop_rate = rospy.Rate(100)

	velocity_publisher = rospy.Publisher("/turtle1/cmd_vel", Twist, queue_size = 10)
	
	while True:
	
		vel_msg.linear.x = 1.0 * getDistance(current_pose.x, current_pose.y, goal_pose.x, goal_pose.y);
		vel_msg.linear.y = 0;
		vel_msg.linear.z = 0;
	
		vel_msg.angular.x = 0;
		vel_msg.angular.y = 0;
		vel_msg.angular.z = 4.0 * (math.atan2(goal_pose.y-current_pose.y,goal_pose.x-current_pose.x)-current_pose.theta);

		velocity_publisher.publish(vel_msg);
		loop_rate.sleep();
		if getDistance(current_pose.x, current_pose.y, goal_pose.x, goal_pose.y) < distance_tolerance :
			rospy.loginfo("goal reached")
			break
	
	vel_msg.linear.x = 0;
	vel_msg.angular.z = 0;
	velocity_publisher.publish(vel_msg);

def getDistance(x1, y1, x2, y2):
	return math.sqrt(pow((x1-x2),2)+pow((y1-y2),2))

def gridClean():
	loop = rospy.Rate(0.5);
	pose = Pose()

	pose.x = 1
	pose.y = 1
	pose.theta = 0
	moveGoal(pose,0.01)
	loop.sleep()
	setDesiredOrientation(0.000000)
	loop.sleep()

	move(2, 9, True)
	loop.sleep()
	rotate(degrees2radians(10), degrees2radians(90), False)
	loop.sleep()
	move(2, 9, True)
	loop.sleep()

	rotate(degrees2radians(10), degrees2radians(90), False)
	loop.sleep()
	move(2, 1, True)
	loop.sleep()
	rotate(degrees2radians(10), degrees2radians(90), False)
	loop.sleep()
	move(2, 9, True)
	loop.sleep()
	
	rotate(degrees2radians(10), degrees2radians(90), True)
	loop.sleep()
	move(2, 1, True)
	loop.sleep()
	rotate(degrees2radians(10), degrees2radians(90), True)
	loop.sleep()
	move(2, 9, True)
	loop.sleep()


def spiralClean():
	global current_pose
	vel_msg = Twist()

	count = 0;
	constant_speed = 4
	rk = 1
	loop = rospy.Rate(1)
	
	velocity_publisher = rospy.Publisher("/turtle1/cmd_vel", Twist, queue_size = 10)

	while True :
		rk = rk+0.5;
		vel_msg.linear.x = rk
		vel_msg.linear.y = 0
		vel_msg.linear.z = 0
	
		vel_msg.angular.x = 0
		vel_msg.angular.y = 0
		vel_msg.angular.z = constant_speed

		velocity_publisher.publish(vel_msg)

		loop.sleep()
	
		if current_pose.x>10.5 or current_pose.y>10.5 :
			rospy.loginfo("boundary reached")
			break
	vel_msg.linear.x = 0
	vel_msg.angular.z = 0
	velocity_publisher.publish(vel_msg)


if __name__ == "__main__" :
	try:
		#velocity_publisher = rospy.publisher("/turtle1/cmd_vel", Twist, queue_size = 10)
		while(flag):		
			rospy.init_node("robot_cleaner_python", anonymous = True)
			pose_subscriber = rospy.Subscriber("/turtle1/pose", Pose, poseCallback)
			loop_rate = rospy.Rate(1)
			print(" Enter your choice ")
			print("1. grid clean")
			print("2. spiral clean")
			print("3. exit")
			print("------------------")
			print("choice = ",end=" " )
			choice = int(input())
		
			if choice==3 :
				flag = False
				break
			if choice==1:
				gridClean()
				loop_rate.sleep()
				#rospy.spin()
			if choice==2:
				spiralClean()
				loop_rate.sleep()
				
			else:
				print("invalid choice")
			rospy.spin()
		
			
		
		

	except rospy.ROSInterruptException:
		rospy.loginfo("node terminated.")
