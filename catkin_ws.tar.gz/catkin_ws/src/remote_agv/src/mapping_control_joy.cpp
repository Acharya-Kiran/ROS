#include "ros/ros.h"
#include<geometry_msgs/Twist.h>
#include<std_msgs/Float32.h>
#include<sensor_msgs/Joy.h>
#include<sensor_msgs/Imu.h>
#include <fstream>
using namespace std; 
typedef struct
{
    int x;
    int y; 
} point;

float inplace_direction_axis;
float turn_direction_axis;
float staight_direction_axis;
ros::Publisher right_pub;
ros::Publisher left_pub;


bool record_point_flag = 0 ;
vector<point> points;
point current_point;
point previous_points;

void record_pointCb(const sensor_msgs::Imu::ConstPtr& msg){
    /*float mag_x = msg->magnetometer.x*cos(pitch) + magReadY*sin(roll)*sin(pitch) + magReadZ*cos(roll)*sin(pitch)
    float mag_y = magReadY * cos(roll) - magReadZ * sin(roll)
    yaw = 180 * atan2(-mag_y,mag_x)/M_PI;
    */
    int s = points.size();
    ROS_INFO("Size of vector    [%d]",s);
    if (record_point_flag){
	current_point.x = msg->linear_acceleration.x;
	current_point.y = msg->linear_acceleration.y;
        //Condition two check if previous point is not too close 
        if(1){
            points.push_back(current_point);
  //FILE* ptr = fopen("abc.dat","wb");
  //fwrite( points, sizeof(points), current_point, ptr);
  //fclose(ptr);
	ROS_INFO("x    [%d]",points[0].x);
            previous_points.x = current_point.x;
            previous_points.y = current_point.y;

        }
     record_point_flag=0;

    }
}



void joyCb(const sensor_msgs::Joy::ConstPtr& msg){
    inplace_direction_axis = msg->axes[2];
    staight_direction_axis = msg->axes[1];
    turn_direction_axis =  msg->axes[0];
    ROS_INFO("Size of vector    [%d]",msg->buttons[1]);
    if(msg->buttons[1]==1.0){
         record_point_flag = 1;
    }
    

}


std::map<std::string,float> splitTwist(){
    //std::cout<<"Linear Velocity:  "<<v<<"\n";
    std::map<std::string,float> wheel_vel;
    float right_wheel = 0.0;
    float left_wheel = 0.0;
    ROS_INFO("inplace_direction_axis[%f] , turn_direction_axis[%f] ",inplace_direction_axis,turn_direction_axis);
    
    if(inplace_direction_axis != -0.0){
        right_wheel = 1.4*inplace_direction_axis;
        left_wheel =  -1.4*inplace_direction_axis;  
    }
    else if(staight_direction_axis != -0.0){
        ROS_INFO("turn_direction_axis    [%f]",turn_direction_axis);
        if(turn_direction_axis !=-0.0){
	    float low_ratio_value,high_ratio_value;
            ROS_INFO("left_wheel    [%f]",turn_direction_axis);
            if(turn_direction_axis>0.0){
                left_wheel = 0.6*staight_direction_axis*1.4;
                right_wheel = 0.8*staight_direction_axis*1.4;
		//left_wheel = turn_direction_axis*100;

            }
            else{
                left_wheel = 0.8*staight_direction_axis*1.4;
                right_wheel = 0.6*staight_direction_axis*1.4;
            }
        }
        else{
            right_wheel= 1.4*staight_direction_axis;
            left_wheel = 1.4*staight_direction_axis;
        }
    }
    else if(staight_direction_axis == -0.0){
        if(turn_direction_axis !=-0.0){
            if(turn_direction_axis>0.0){
                left_wheel = 0.0;
                right_wheel = 1.4;
            }
            else{
                left_wheel = 1.4;
                right_wheel = 0.0   ;
            }


        }
    }
    wheel_vel["v_r"] = right_wheel;
    wheel_vel["v_l"] = left_wheel;
    return wheel_vel;
    
}




void set_wheel_speed(){
        ros::Rate loop_rate(100);
        std_msgs::Float32 l_vel; 
        std_msgs::Float32 r_vel;
        while(ros::ok()){
            std::map<std::string,float> get_speed = splitTwist();
            ROS_INFO("Left Wheel Velocity [%f] , Right Wheel Velocity [%f] ", get_speed["v_l"], get_speed["v_r"]);
            l_vel.data =  get_speed["v_l"];
            r_vel.data =  get_speed["v_r"];
            left_pub.publish(l_vel);
            right_pub.publish(r_vel);
            ros::spinOnce();
            loop_rate.sleep();
        }
        
}



int main(int arg,char **argc){
    ros::init(arg,argc,"mapping_control_joy");
    ros::NodeHandle nh;
    ros::Subscriber sub = nh.subscribe("/joy",5,joyCb);
    ros::Subscriber points_sub = nh.subscribe("/imu",5,record_pointCb);
    right_pub = nh.advertise<std_msgs::Float32>("wheel_power_right",1);
    left_pub = nh.advertise<std_msgs::Float32>("wheel_power_left",1);
    set_wheel_speed();  
    ros::spin();
    return 0;
}



