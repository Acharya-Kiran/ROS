#include "ros/ros.h"
#include<geometry_msgs/Twist.h>
#include<std_msgs/Float32.h>

float v , w;
float  wheel_base=200.0,wheel_radius=75.0,wheel_max_speed=1.35,wheel_min_speed=0;
ros::Publisher right_pub;
ros::Publisher left_pub;

void twistCb(const geometry_msgs::Twist::ConstPtr& msg){
    v = msg->linear.x;
    w = msg->angular.z;
    //ROS_INFO("Linear Velocity [%f] , Angular Velocity [%f] ", v,w);
}

std::map<std::string,float> splitTwist(){
    //std::cout<<"Linear Velocity:  "<<v<<"\n";
    std::map<std::string,float> wheel_vel;
    float right_wheel;
    float left_wheel;
    if(w != 0.0){
        right_wheel = ((2*v)+(w*wheel_base))/(2*wheel_radius);
        left_wheel = ((2*v)-(w*wheel_base))/(2*wheel_radius);
    }
    else{
        right_wheel=v;
        left_wheel = v;
    }
    wheel_vel["v_r"] = right_wheel;
    wheel_vel["v_l"] = left_wheel;
    return wheel_vel;
    
}

void set_wheel_speed(){
        ros::Rate loop_rate(10);
        std_msgs::Float32 l_vel; 
        std_msgs::Float32 r_vel;
        while(ros::ok()){
            std::map<std::string,float> get_speed = splitTwist();
            ROS_INFO("Left Wheel Velocity [%f] , Right Wheel Velocity [%f] ", get_speed["v_l"], get_speed["v_r"]);
            l_vel.data =  get_speed["v_l"];
            r_vel.data =  get_speed["v_r"];
            left_pub.publish(l_vel);
            right_pub.publish(r_vel);
            ros::spinOnce();
            loop_rate.sleep();
        }
        
}
int main(int arg,char **argc){
    
    ros::init(arg,argc,"publish_wheel_speed");
    ros::NodeHandle nh;
    
    ros::Subscriber sub = nh.subscribe("cmd_vel",10,twistCb);
    right_pub = nh.advertise<std_msgs::Float32>("wheel_power_right",10);
    left_pub = nh.advertise<std_msgs::Float32>("wheel_power_left",10);
    
    /*ros::param::get("/wheel_base",wheel_base);
    ros::param::get("/wheel_radius",wheel_radius);
    ros::param::get("/wheel_max_speed",wheel_max_speed);
    ros::param::get("/wheel_min_speed",wheel_min_speed);
    */
    ROS_INFO("ROBOT Configurations : \n");
    ROS_INFO("L:    %f\nR:   %f\nMax_Speed  %f\nMin_Speed   %f",wheel_base,wheel_radius,wheel_max_speed,wheel_min_speed);
    set_wheel_speed();  
    ros::spin();
    return 0;

}