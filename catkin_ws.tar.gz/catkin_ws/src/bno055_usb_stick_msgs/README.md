# bno055_usb_stick_msgs
ROS messages associated with Bosch BNO055 USB Stick

## Used by
bno055_usb_stick https://github.com/yoshito-n-students/bno055_usb_stick
